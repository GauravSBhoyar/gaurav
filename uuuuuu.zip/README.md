# myresort-api
Monolithic REST api for MYRESORT App
